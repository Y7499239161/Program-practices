//write a program t accept 2 array of 10 element each and create a 3rd array having sum of both array.

class SumArray{
	public static void main(String[]args){
	 int[] arr1 = {10,20,30,40,50,60,70,80,90,100};
	 int[] arr1 = {10,20,30,40,50,60,70,80,90,100};

	 int[] arr3 = new int[arr1.length];

	 for(int i=0;i<arr1.length;i++){
		arr3[i] = arr1[i] + arr2[i];
	}
	  for(int i=0;i<arr1.length;i++){
	    System.out.println(i);
	}
    }
}
























