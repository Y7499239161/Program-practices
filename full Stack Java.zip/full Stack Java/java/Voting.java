// A program  to accept age and print whether person can vote or not

import java.util.Scanner;
 class Voting{
	public static void main(String[]args){
	int age;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Your age");
	age =sc.nextInt();
	
	if(age>=18){
	   System.out.println("Do you have aadhar card  ? Yes/No");
	   String ch =sc.next();
	   if(ch.equals("yes")){

	  System.out.println("You can Vote");
            }
	else{
	  System.out.println("You can not vote");
	   }
	}
	else{
		 System.out.println("You can Vote");

            }
	  }
    }