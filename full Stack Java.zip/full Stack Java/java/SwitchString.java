import java.util.Scanner;
class SwitchString{
	public static void main(String []args){
	String moviename;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your Favorite movie name");
	moviename=sc.next();
	switch(moviename){
	     case "kabirsingh":System.out.println("Shahid Kapoor,kiara Adwani are actor");
			break;
	     case "citadel":System.out.println("Varun dhavan ,ambithab ,samanthaare actor");
			break;
	     case "kalki":System.out.println("  Prabhas ,amithabh , Deepika are actor");
			break;

		default:System.out.println("I am not knowing about this movie");
		break;

	}
   }
 }
