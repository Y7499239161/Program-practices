class Positiveno{
   int number=5;
    if (no >0){
	System.out.println("Positive");
	}
	else{
	System.out.println("Non-positive");
	}