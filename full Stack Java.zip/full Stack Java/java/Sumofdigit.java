// write a program to accept the no and print sum of digit

import java.util.Scanner;
 class  Sumofdigit{
	public static void main(String[]args){
	  int no;

          Scanner sc=new Scanner(System.in);
	  System.out.println("Enter any number");
	  no=sc.nextInt();
	   int sum=0,d;

           
		 while(no>0){
			d=no %10;
		sum=sum+d;
		no=no/10;
         }
	 System.out.println("The sum of the digit is:"+sum);  
            
         }
    }