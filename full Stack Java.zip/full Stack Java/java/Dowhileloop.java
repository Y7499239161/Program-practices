 class Dowhileloop{	
	public static void main(String[]args){
	int no=1;
	do{
	System.out.println(no);
	 no++=;
	}while(no<=10;);
    }
  }
}