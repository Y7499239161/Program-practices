1. Basic Array Declaration and Traversalpublic  

    class ArrayElement{
	 public static void main(String[]args){
	  int[]number={10,20,30,40,50};
		System.out.println(Array Element);
		for(int nuber:numbers){
		System.out.pritln(numbers);
	 }
 	}
}
   