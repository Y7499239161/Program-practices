class Armstrong{
	
	}
