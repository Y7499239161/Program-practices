import java.util.Scanner;
   class EqualOPerator{
	public static void main(String[]args){
	 int x=5;
	 int y=3;
	y+=x*4;

	System.out.println(x);
        System.out.println(y);


	}
   }
