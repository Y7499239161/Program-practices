class Positive{
   public static void main (String[]args){
   
    if (number >0){
	System.out.println("Positive");
	}
	else{
	System.out.println("Non-positive");
	}
   }
 }