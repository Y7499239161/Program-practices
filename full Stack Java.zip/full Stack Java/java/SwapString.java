class SwapString{
	public static void main(String[] args){
	 	String[] arr1 = {"Yogesh","I"};
		String[] arr2 = {"harshal","You"};
		
		String [] arr3 = new String[arr1.length]; 
		
		for(int i=0;i<arr1.length;i++){
		   arr3[i] = arr1[i];
		   arr1[i] = arr2[i];
		   arr2[i] = arr3[i];
		}
		for(int i=0;i<arr1.length;i++){
		 	System.out.print(" "+arr1[i]);
		}
		 System.out.println();
		for(int i=0;i<arr1.length;i++){
			System.out.print(" "+arr2[i]);
		}
	}
}