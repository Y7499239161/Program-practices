
 //Find the Largest Element in an Array
	class LargestNumber{
		publicstatic void main(String[]args){
 		int[] number={56,78,98,34,89}
		int max=[0];
		for(int number:numbers){
			if(number > max){
			max=number;
				}
				}
	   		System.out.println("Largest Element:"+max);
			}
           }







