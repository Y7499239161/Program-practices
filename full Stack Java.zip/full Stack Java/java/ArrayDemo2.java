class  ArrayDemo2{
	public static void main(String[]args){
	 int marks[]={98,87,98,64,78,23,67};
	 System.out.println("The Size of array:"+marks.length);
	
	 for(int i=0;i<marks.length;i++){
	   System.out.println(marks[i]);
	  }
	   System.out.println("2nd element:" +marks[2]);
		marks[1]=87;
              System.out.println("1nd element:" +marks[2]);
		


	}
      }
