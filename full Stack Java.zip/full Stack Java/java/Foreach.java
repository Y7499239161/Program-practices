	//for each loop
	//for(datatype variablename:ArreyName){
	     }
  class  ForEachDemo{
	public static void main(String[]args){
	 int marks[]={98,87,98,64,78,23,67};
	 foreach(int m:marks){
	 System.out.println(m);
   }
  }
}
