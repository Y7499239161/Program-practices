
 //Find the Largest Element in an Array
	class LargestNumber{
		public static void main(String[]args){
 		int[] numbers={56,78,98,34,89};
		int max=numbers[0];
		for(int number:numbers){
			if(number > max){
			max=number;
				}
				}
	   		System.out.println("Largest Element:"+max);
			}
           }







