class Array{
	public static void main(String []args){
	 int[]a={23,45,67,4,6,77,845};
	 System.out.println(a[5]);
	 System.out.println(a[4]);
	 System.out.println(a[6]);
	 System.out.println("The size of array:"+a.length);
	}
  }