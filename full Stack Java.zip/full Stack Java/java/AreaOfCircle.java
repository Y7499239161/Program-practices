import java.util.Scanner;

  class  AreaOfCircle{
	public static void main(String []args){
	float radius;
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter Radius of Circle");
	radius=sc.nextFloat();

	System.out.println("The radius is: "+radius);
	System.out.println("The Area Of circle is:"+(3.14*radius*radius)  );
	

	   }

}



