
class  ArrayDemo1{
	public static void main(String[]args){
	 int[]a=new int[10] ;
	  System.out.println(a[4]);
	  System.out.println(a[9]);

	/*array intialization
	// int[]a={60,23,65,8,23,757,13};
	//  System.out.println(a[4]);
	//  System.out.println(a[5]);
	//  System.out.println("Thesize of array:"+a.length);
	}
 }*/




