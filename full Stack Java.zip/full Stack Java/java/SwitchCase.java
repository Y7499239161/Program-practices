import java.util.Scanner;
class SwitchCase{
	public static void main(String []args){
	int size;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Your Size Of T-Shirt");
	size=sc.nextInt();
	switch(size){
	    case 38:System.out.println(" Your  Of T-Shirt S");
	            System.out.println("Price:Rs.400/-");
			break;
	    case 40:System.out.println(" Your  Of T-Shirt M");
	            System.out.println("Price:Rs.500/-");
			break;
	    case 42:System.out.println(" Your  Of T-Shirt L");
	            System.out.println("Price:Rs.600/-");
			break;
	     case 48:System.out.println(" Your  Of T-Shirt XXXL");
	            System.out.println("Price:Rs.1000/-");
			break;
	   default:System.out.println(" Your  Of T-Shirt Not Available");
	          
	}
  }
}