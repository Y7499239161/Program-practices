 import java.util.Scanner;

class WhileDemo2{
	public static void main(String[]args){ 
	  int no=1;
	 
	
	while(no<=10){
	   if(no%3==0)
	   System.out.println(no);
	
	   no++;
	}
		
     }
 }

