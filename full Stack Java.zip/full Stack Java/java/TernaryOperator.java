import java.util.Scanner;
class TernaryOperator{
	public static void main(String[]args){
	 int a,b;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter any two numbers");
	
	a=sc.nextInt();
	b=sc.nextInt();
	int max= a>b?a:b;
	System.out.println("Maximum:" +max);
	

     }
  }
