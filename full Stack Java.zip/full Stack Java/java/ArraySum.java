// Sum of All Elements in an Array
 class Arraysum{
public class ArraySum {

    public static void main(String[] args) { 
       int[] numbers = {5, 10, 15, 20, 25};
        int sum = 0;
        for (int number : numbers) {

            sum += number;        

        System.out.println("Sum of Elements: " + sum);
    }
  }
 }
}