// write a program to accept 2 array of 10 element each and swap the arrays.

class SwapArray{
	public static void main(String[]args){
	   int[] arr1 = {34,56,78,8};
	   int[] arr2 = {45,6,78,56};
		
	  for(int i=0;i<arr1.length;i++){
		arr1[i] = arr1[i] + arr2[i];
		arr2[i] = arr1[i] - arr2[i];
		arr1[i] = arr1[i] - arr2[i]; 
	}
		  for(int i=0;i<arr1.length;i++){	
			System.out.print( " "+arr1[i]);
		 }
		  System.out.println();

		
		   for(int i=0;i<arr1.length;i++){
		            System.out.print(" "+arr2[i]);
		}
		 System.out.println();
	
	}
}





