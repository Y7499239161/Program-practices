//1. Basic Array Declaration and Traversalpublic  

    class ArrayElement{
	 public static void main(String[]args) {
	  int[] numbers={10,20,30,40,50};
		System.out.println("Array Elements:");
		for(int number:numbers){
		System.out.println(number);
	 }
 	}
}


	