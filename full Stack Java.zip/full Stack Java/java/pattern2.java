class pattern2{
	public static void main(String[]args){
	int no=5;
	for(int i=0;i<=5;i++){
	    for(int j=1;j<=i;j++){
		System.out.print(" "+j);
			}
			System.out.println();
			
		}
	}
}