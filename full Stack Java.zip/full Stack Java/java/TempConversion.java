import java.util.Scanner;

  class TempConversion{
	public static void main(String []args){
	float f,c;

	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the temperature in fahrenheit");
	f=sc.nextFloat();
	c=(f-32)*(5/9);

	System.out.println("The temperature in fahrenheit: "+f);	
	System.out.println("The temperature in Celcus: "+c );
        }
    }
